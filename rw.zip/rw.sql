-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 27, 2025 at 08:56 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.2.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rw`
--

-- --------------------------------------------------------

--
-- Table structure for table `iuran_sampah`
--

CREATE TABLE `iuran_sampah` (
  `id` int(11) NOT NULL,
  `bulan` varchar(10) DEFAULT NULL,
  `tahun` varchar(10) DEFAULT NULL,
  `total_pemasukan` varchar(50) DEFAULT NULL,
  `keterangan` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iuran_sampah`
--

INSERT INTO `iuran_sampah` (`id`, `bulan`, `tahun`, `total_pemasukan`, `keterangan`, `created_at`) VALUES
(1, '02', '2025', '40000000', 'Lunas', '2025-05-26 23:36:59'),
(2, '03', '2024', '8950000', 'Lunas', '2025-05-26 23:21:03'),
(4, '09', '2024', '44000000', 'Lunas', '2025-05-26 23:40:48');

-- --------------------------------------------------------

--
-- Table structure for table `keuangan`
--

CREATE TABLE `keuangan` (
  `id` int(11) NOT NULL,
  `bulan` varchar(20) DEFAULT NULL,
  `tahun` int(11) DEFAULT NULL,
  `total_pemasukan` varchar(50) DEFAULT NULL,
  `keterangan` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `pengaduan`
--

CREATE TABLE `pengaduan` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `laporan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `username`, `password`) VALUES
(1, 'user', 'user');

-- --------------------------------------------------------

--
-- Table structure for table `warga`
--

CREATE TABLE `warga` (
  `id` int(11) NOT NULL,
  `nama_lengkap` varchar(100) DEFAULT NULL,
  `nik` varchar(20) DEFAULT NULL,
  `jenis_kelamin` varchar(10) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `alamat_asal` varchar(255) DEFAULT NULL,
  `alamat_tujuan` varchar(255) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `keterangan` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `warga`
--

INSERT INTO `warga` (`id`, `nama_lengkap`, `nik`, `jenis_kelamin`, `status`, `alamat_asal`, `alamat_tujuan`, `tanggal`, `keterangan`, `created_at`) VALUES
(1, 'Budi', '5425345345345', NULL, 'pindah', 'Jl. Bandung', 'Jl. Jakarta', '2025-05-07', '', '2025-05-07 16:19:04'),
(2, 'swq', '5425345345345', 'laki-laki', 'tinggal', 'wswqs', '-', '2025-05-07', 'wsqwswqs', '2025-05-07 16:19:26'),
(3, '', '', NULL, NULL, '', '', '0000-00-00', '', '2025-05-07 16:19:36'),
(4, 'swq', '5425345345345', 'laki-laki', 'tinggal', 'wswqs', '-', '2025-05-07', 'wsqwswqs', '2025-05-07 16:21:39'),
(5, 'swq', '5425345345345', 'laki-laki', 'tinggal', 'wswqs', '-', '2025-05-07', 'wsqwswqs', '2025-05-07 16:21:55'),
(7, 'Ahmad Yani', '5425345345345', NULL, 'tinggal', '', '', '0000-00-00', '', '2025-05-07 16:23:10'),
(8, '', '', NULL, NULL, '', '', '0000-00-00', '', '2025-05-07 16:28:23'),
(9, '', '', NULL, NULL, '', '', '0000-00-00', '', '2025-05-15 05:15:12'),
(10, 'swq', '', 'perempuan', NULL, '', '', '0000-00-00', '', '2025-05-15 05:15:49'),
(11, 'swq', '', 'perempuan', NULL, '', '', '0000-00-00', '', '2025-05-15 05:17:00'),
(12, 'dgfdsfg', '3518200309030001', 'laki-laki', NULL, '', '', '0000-00-00', '', '2025-05-15 05:20:08'),
(13, 'jairo', '3518200309030001', 'Laki-laki', 'kawin', 'wswqs', 'jl.ir.rais', '2025-05-15', '', '2025-05-15 05:35:09'),
(14, 'jairo', '3518200309030001', 'Laki-laki', 'kawin', 'wswqs', 'jl.ir.rais', '2025-05-15', '', '2025-05-15 05:35:36'),
(15, 'swq', '3518200309030001', 'Laki-laki', 'kawin', 'wswqs', 'jl.ir.rais', '2025-05-15', '', '2025-05-15 05:38:07'),
(16, 'aewrtwr4t', '3520032401060002', 'Laki-laki', 'kawin', 'wswqs', 'jl.ir.rais', '2025-05-15', '', '2025-05-15 05:42:07'),
(17, 'Toha', '3520032401060002', 'Laki-laki', 'kawin', 'wswqs', 'jl.ir.rais', '2025-05-15', '', '2025-05-15 05:43:20'),
(18, 'Ahmad Yani', '39993950', 'Laki-laki', 'Menikah', 'Jl. Bandung', 'Jl. Jakarta', '2025-05-26', 'Pindah Tetap', '2025-05-26 04:52:56'),
(19, 'Ahmad Yani', '39993950', 'Perempuan', 'Menikah', 'Jl. Bandung', 'Jl. Jakarta', '2025-05-26', '', '2025-05-26 05:06:05'),
(20, 'Ahmad Yani', '39993950', 'Laki-laki', 'Menikah', 'Jl. Bandung', 'Jl. Jakarta', '2025-05-01', '', '2025-05-26 05:08:17'),
(21, 'Budi', '1234567890', 'Laki-laki', 'Menikah', 'Jl. Bandung', 'Jl. Jakarta', '2025-05-26', '', '2025-05-26 05:26:14');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `iuran_sampah`
--
ALTER TABLE `iuran_sampah`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `keuangan`
--
ALTER TABLE `keuangan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pengaduan`
--
ALTER TABLE `pengaduan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `warga`
--
ALTER TABLE `warga`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `iuran_sampah`
--
ALTER TABLE `iuran_sampah`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `keuangan`
--
ALTER TABLE `keuangan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pengaduan`
--
ALTER TABLE `pengaduan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `warga`
--
ALTER TABLE `warga`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
